""" 
Name: Emma Boutoille
Date: November 1 
S5.1 Avoiding Game Tutorial
"""   
# ------------------------------------- Imports ----------------------------------
import random # import random library 
import turtle # import turtle
import time # import time 
 
# ----------------------------------- Window Setup ----------------------------------
wn = turtle.Screen() # create window called wn
wn.setup(width = 1.0, height = 1.0, startx=None, starty=None) # setup window width and height
wn.title("A4.1 Avoiding and Collecting") # Window title 
wn.bgpic("stars.gif") # set background pic to stars.gif
wn.tracer(0) # turn off updates for faster animation 
wn.register_shape("pig.gif") # register pig.gif
wn.register_shape("plum.gif") # register plum.gif
wn.register_shape("playerright.gif") # register playerright.gif
wn.register_shape("playerleft.gif") # register playerleft.gif
wn.register_shape("heart.gif") # register heart.gif
# ---------------------------------- Turtle Setup ----------------------------------
player = turtle.Turtle() # create player
player.shape("playerright.gif") # set shape to player right 
player.speed(1) # set animation speed 
player.pu() # penup 
player.goto(0, -300) # go to the bottom of the screen 

pen = turtle.Turtle() # create a pen turtle
pen.ht() # hide the pen turtle
penstyle_score = ("Roboto Slab", 20, "bold") # set font, size, and style for the score
pen.color("DeepPink") # set the pen color

life1 = turtle.Turtle() # create a life turtle
life1.pu() # pen up
life1.shape("heart.gif") # give the life turtle a heart shape
life1.goto(-400,350) # move life1 to -400, 350

life2 = turtle.Turtle() # create another life turtle
life2.pu() # pen up
life2.shape("heart.gif") # give the life turtle a heart shape
life2.goto(-350,350) # move life2 to -350, 350

life3 = turtle.Turtle() # create another life turtle
life3.pu() # pen up
life3.shape("heart.gif") # give the life turtle a heart shape
life3.goto(-300,350) # move life3 to -300, 350

life4 = turtle.Turtle() # create another life turtle
life4.pu() # pen up
life4.shape("heart.gif") # give the life turtle a heart shape
life4.goto(-250,350) # move life4 to -250, 350

life5 = turtle.Turtle() # create another life turtle
life5.pu() # pen up
life5.shape("heart.gif") # give the life turtle a heart shape
life5.goto(-200,350) # move life5 to -200, 350

# Create a list of friends 
many_friends = [] # this is an empty list 
time.sleep(1) # wait one second

for i in range(4): # make 4 friends
  friend = turtle.Turtle() # create item to friend 
  friend.shape("plum.gif") # set shape to circle
  friend.color("blue") # set color 
  friend.pu() # pen up 
  int_x = random.randint(-390, 390) # get a random x value
  friend.goto(int_x, 350) # move up to the top
  friend.speed = random.randint(1,4) # set animation speed 
  many_friends.append(friend) # append friend to many_friends list

# Create a list of enemies
many_enemies = [] # this is an empty list 

for i in range(4): # make 4 friends
  enemy = turtle.Turtle() # create item to friend 
  enemy.shape("pig.gif") # set shape to circle
  enemy.color("red") # set color 
  enemy.pu() # pen up 
  int_x = random.randint(-390, 390) # get a random x value
  enemy.goto(int_x, 350) # move up to the top
  enemy.speed = random.randint(1,4) # set animation speed 
  many_enemies.append(enemy) # set the falling speed

# ------------------------------- Global Variables ----------------------------------
player.direction = "stop" # initialize direction of player
int_score = 0 # set score to 0
int_lives = 5 # set lives to 5
penstyle = ("Arial", 50, "bold") # set font, size, and style 

# ------------------------------- Functions ----------------------------------
def move_left(): # create a function to set direction to left
  player.direction = "left" # set direction to left
  player.shape("playerleft.gif") # set shape to player left

def move_right(): # create a function to set direction to right
  player.direction = "right" # set diretcion to right
  player.shape("playerright.gif") # set shape to player right

def player_direction(): # create a function to change ht e player direction
  if player.direction == "left": # check if direction is left
    if player.xcor() > -380: # keep moving if greater than -380
      int_x = player.xcor() # get the player current x position
      int_x -= 1 # subtract 1 to move left
      player.setx(int_x) # set player x pos to the x value 

  if player.direction == "right": # check if direction is right
    if player.xcor() <= 380: # keep moving if less than 380
      int_x = player.xcor() # get the player current x position
      int_x += 1 # add 1 to move right
      player.setx(int_x) # set player x pos to the x value 

def move_friends(): # create a function to move the friends
  global int_score # global variable for score 
  # move friend down 
  for friend in many_friends:
    int_y = friend.ycor() # get the friend current y position 
    int_y -= friend.speed # subtract random to move down
    friend.sety(int_y) # set friend x pos to the y value
    # check  when friend is at bottom
    if int_y <= -350: # check when at bottom
      int_x = random.randint(-390, 390) # get a random x value
      friend.goto(int_x, 350) # move up to the top
    # check for collision with player and friend 
    if friend.distance(player) < 20: # check if center of player and friend are within 20
      int_x = random.randint(-390, 390) # get a random x value
      friend.goto(int_x, 350) # move up to the top
      pen.clear() # clear everything the pen turtle wrote
      int_score += 10 # add 10 to the score
      pen.pu() # pen up
      pen.goto(280,350) # move pen to 280, 350
      pen.pd() # pen down
      pen.write("Score: " +str(int_score), font = penstyle_score) # write the score
      
def move_enemies(): # create a function to move the enemies
  global int_lives # global variable for lives
  # move enemies down
  for enemy in many_enemies:
    int_y = enemy.ycor() # get the enemy current y position 
    int_y -= enemy.speed # subtract random to move down
    enemy.sety(int_y) # set enemy x pos to the y value
    # check  when enemy is at bottom
    if int_y <= -350: # check when at bottom
      int_x = random.randint(-390, 390) # get a random x value
      enemy.goto(int_x, 350) # move up to the top
    # check for collision with player and enemy
    if enemy.distance(player) < 20: # check if center of player and enemy are within 20
      int_x = random.randint(-390, 390) # get a random x value
      enemy.goto(int_x, 350) # move up to the top
      int_lives -= 1 # lose 1 life
      if int_lives == 4: # check if there are 4 lives left
        life5.ht() # hide life5 turtle
      elif int_lives == 3: # check if there are 3 lives left
        life4.ht() # hide life4 turtle
      elif int_lives == 2: # check if there are 2 lives left
        life3.ht() # hide life3 turtle
      elif int_lives == 1: # check if there are 1 lives left
        life2.ht() # hide life2 turtle

def end_game(): # When game is over
  for enemy in many_enemies: # for all enemies
    enemy.ht() # hide enemies 
  for friend in many_friends: # for all friends 
    friend.ht() # hide friends 
  player.ht() # hide player 
  pen.clear() # clear the score 
  pen.pu() # lift pen up
  pen.goto(0,0) # move pen to middle 
  pen.color("green") # set pen color to green
  pen.write("Game Over", font = penstyle, align = "center") # write game over message
 
# ------------------------------- Main Program ----------------------------------
wn.listen() # listen for a key to be pressed 
wn.onkeypress(move_left, "Left") # Left arrow key calls
wn.onkeypress(move_right, "Right") # Left arrow key calls

while int_lives >= 0: # Now loop as long as lives > 0
  wn.update() # update screen
  player_direction() # call player direction update function
  move_friends() # move all your friends
  move_enemies() # move all your enemies
  if int_lives <= 0: # if there a no lives left
    life1.ht() # hide life1 turtle
    end_game() # call on end_game function



